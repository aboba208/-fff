$(call inherit-product, $(SRC_TARGET_DIR)/product/base.mk)
$(call inherit-product, vendor/twrp/config/common.mk)
$(call inherit-product, device/itel/L6006/device.mk)

PRODUCT_DEVICE := L6006
PRODUCT_NAME := twrp_L6006
PRODUCT_BRAND := itel
PRODUCT_MODEL := itel L6006
PRODUCT_MANUFACTURER := ITEL MOBILE LIMITED
