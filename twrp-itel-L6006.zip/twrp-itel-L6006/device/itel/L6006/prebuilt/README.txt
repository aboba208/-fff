kernel/dtb/dtbo are extracted from the stock recovery.img by the workflow
