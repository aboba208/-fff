PRODUCT_USE_DYNAMIC_PARTITIONS := true
PRODUCT_PACKAGES += fastbootd android.hardware.fastboot@1.0-impl-mock
