# TWRP for itel A48 (L6006), Unisoc SC9832E, Android 10 Go (32-bit)
Untested device tree. Build: Actions -> "Build TWRP itel L6006" -> Run workflow, paste the Google Drive file ID of your stock recovery.img (link must be shared "anyone with the link").
Flash (bootloader unlocked): fastboot flash vbmeta vbmeta_disabled.img ; fastboot flash recovery twrp-itel-L6006.img
Keep your stock recovery.img as a backup.
