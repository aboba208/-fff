#!/bin/bash
# usage: repack.sh <stock_unpack_dir> <twrp_ramdisk> <mkbootimg.py> <out.img>
set -e
S=$1; RD=$2; MK=$3; OUT=$4
case "$RD" in *.cpio) gzip -9 -c "$RD" > /tmp/rd.gz; RD=/tmp/rd.gz;; esac
python3 "$MK" --header_version 2 --kernel "$S/kernel" --ramdisk "$RD" \
  --dtb "$S/dtb" --recovery_dtbo "$S/recovery_dtbo" \
  --base 0x00000000 --pagesize 2048 --kernel_offset 0x00008000 --ramdisk_offset 0x05400000 \
  --second_offset 0x00f00000 --tags_offset 0x00000100 --dtb_offset 0x01715000 \
  --os_version 10.0.0 --os_patch_level 2020-12 \
  --cmdline "console=ttyS1,115200n8 buildvariant=user" -o "$OUT"
SZ=$(stat -c %s "$OUT"); echo "image size: $SZ (partition limit 36700160)"
[ "$SZ" -le 36700160 ] || { echo "ERROR: image larger than recovery partition"; exit 1; }
