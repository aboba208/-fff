import struct,sys
h=b'AVB0'+struct.pack(">II",1,0)+struct.pack(">QQ",0,0)+struct.pack(">I",0)+struct.pack(">"+"Q"*10,*[0]*10)+struct.pack(">Q",0)+struct.pack(">I",3)+struct.pack(">I",0)+b'avbtool 1.1.0'.ljust(48,b'\0')
open(sys.argv[1],'wb').write(h.ljust(256,b'\0').ljust(4096,b'\0'))
